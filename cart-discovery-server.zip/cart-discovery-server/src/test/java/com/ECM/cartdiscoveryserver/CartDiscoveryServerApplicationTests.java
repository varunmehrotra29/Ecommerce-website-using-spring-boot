package com.ECM.cartdiscoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
